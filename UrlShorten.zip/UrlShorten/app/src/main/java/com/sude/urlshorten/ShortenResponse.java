package com.sude.urlshorten;



public class ShortenResponse {

    private String link;

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}

